import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthorizationService } from '../../services/authorization.service';
import { Observable } from 'rxjs';
import { IUserDetails } from '../../../modules/shared/interfaces/icommon';
import { CookieService } from 'ngx-cookie-service';
import { StorageHelper } from '../../services/storage-helper.service';
import { ApplicationHeaderService } from '../../../layout/services/application-header.service';
import { LoginService } from '../../services/login.service';
import { SidebarService } from 'src/app/layout/services/sidebar.service';

@Component({
    selector: 'app-login',
    templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {

    constructor(private _authService: AuthorizationService, private _router: Router, private _cookieService: CookieService,
        private storageHelper: StorageHelper, private _applicationHeaderService: ApplicationHeaderService, private _loginService: LoginService,
        private _sidebarService: SidebarService) { }

    cookieValue: string;
    relayState: string;
    loggedInUserDetails: IUserDetails = {};
    userName: string = '';
    password: string = '';
    loadingData: boolean = false;

    nextButtonClicked() {
        // let encryptedRelayState = this._cookieService.get('relayState');
        // this.relayState = atob(encryptedRelayState);
        if (this.storageHelper.getItem('loggedInUserDetails') == null) {
            this._cookieService.set('userName', this.userName);
            this.cookieValue = this._cookieService.get('userName');
            //this.cookieValue = this._cookieService.get('samlData');
            //this.cookieValue = atob(this.cookieValue);
            if (this.cookieValue != "" && this.cookieValue != undefined) {
               // this.loadingData = true;
            //    this.loggedInUserDetails.CommonName=this.userName;
            //    this.loggedInUserDetails.LoginName=this.userName;
            //    this.storageHelper.setItem("loggedInUserDetails", this.loggedInUserDetails);

            //    this._applicationHeaderService.editLoggedInUserDetails(this.loggedInUserDetails);
             
                //     this._router.navigateByUrl('/dashboard');
                this._loginService.getAuthenticateUserDetails(this.userName, this.password).subscribe(response => {
                    this.loadingData = false;
                    if (response!=null) {
                        this._cookieService.delete("userName");
                        this.loggedInUserDetails.CommonName = response.FirstName + ' ' + response.LastName;
                        this.loggedInUserDetails.LoginName = this.userName;
                        this.loggedInUserDetails.Roles = response.Role.trim();

                        if (this.loggedInUserDetails != null && this.loggedInUserDetails != undefined && Object.keys(this.loggedInUserDetails).length > 0) {
                            this.storageHelper.setItem("loggedInUserDetails", this.loggedInUserDetails);
                            this._applicationHeaderService.editLoggedInUserDetails(this.loggedInUserDetails);
                            // if (this.loggedInUserDetails.Roles.length > 0) {
                            //     for (var i = 0; i < this.loggedInUserDetails.Roles.length; i++) {

                            //         if (this.loggedInUserDetails.Roles[i].toLowerCase().includes("buyer") || this.loggedInUserDetails.Roles[i].toLowerCase().includes("gso")) {
                            //             this.storageHelper.setItem("selectedRole", "buyer");
                            //             break;
                            //         }
                            //         else if (this.loggedInUserDetails.Roles[i].toLowerCase().includes("fna")) {
                            //             this.storageHelper.setItem("selectedRole", "fna");
                            //             break;
                            //         }
                            //         else if (this.loggedInUserDetails.Roles[i].toLowerCase().includes("admin")) {
                            //             this.storageHelper.setItem("selectedRole", "fddAdmin");
                            //             break;
                            //         }
                            //     }
                            // }
                            //this.ProcessRelayStateData();
                            // this.navigateToFigOrBuyerDashboard();
                            this._router.navigateByUrl('/actions');
                        }
                        else {
                            this._router.navigateByUrl('/unauthorized');
                        }
                    } else {
                        this._router.navigateByUrl('/unauthorized');
                    }
                 },
                     err => {
                         this.loadingData = false;
                         this._router.navigateByUrl('/unauthorized');
                     })
            }
            else {
                //redirect To PING URL
                //window.location.href = 'https://fedauthtst.pg.com/idp/startSSO.ping?PartnerSpId=https%3A%2F%2Fsigfadev.pg.com%3A8312%2Flogin&targetResource=';
                //window.location.href = 'https://fedauthtst.pg.com/idp/startSSO.ping?PartnerSpId=https%3A%2F%2Fsgraqa.pg.com%3A8212%2Flogin';
            }
        }
        else {
            this.loggedInUserDetails = this.storageHelper.getItem('loggedInUserDetails');
            this._applicationHeaderService.editLoggedInUserDetails(this.loggedInUserDetails);
            //this.ProcessRelayStateData();
            this._router.navigateByUrl('/actions');
        }
    }

    ngOnInit() {
        this._sidebarService.editSidebarShowValue(false);
        //let encryptedRelayState = this._cookieService.get('relayState');
        //this.relayState = atob(encryptedRelayState);
        //if (this.storageHelper.getItem('loggedInUserDetails') == null) {
        //  this._cookieService.set('userName', 'agrawal.as');
        //  this.cookieValue = this._cookieService.get('userName');
        //  //this.cookieValue = this._cookieService.get('samlData');
        //  //this.cookieValue = atob(this.cookieValue);
        //  if (this.cookieValue != "" && this.cookieValue != undefined) {
        //    $("#loadingModal").modal("show");
        //    this._authService.getLoggedInUserDetails(this.cookieValue).subscribe(response => {
        //      $("#loadingModal").modal("hide");
        //      this._cookieService.delete("userName");
        //      this.loggedInUserDetails = <IUserDetails>response.body;
        //      this.storageHelper.setItem("loggedInUserDetails", this.loggedInUserDetails);          
        //      if (this.loggedInUserDetails != null) {
        //        this._applicationHeaderService.editLoggedInUserDetails(this.loggedInUserDetails);
        //        //this.ProcessRelayStateData();
        //        this._router.navigateByUrl('/dashboard');
        //      }
        //      else {
        //        this._router.navigateByUrl('/unauthorized');
        //      }
        //    },
        //      err => {
        //        $("#loadingModal").modal("hide");
        //        this._router.navigateByUrl('/unauthorized');
        //      })
        //  }
        //  else {
        //    //redirect To PING URL
        //    //window.location.href = 'https://fedauthtst.pg.com/idp/startSSO.ping?PartnerSpId=https%3A%2F%2Fsigfadev.pg.com%3A8312%2Flogin&targetResource=';
        //    //window.location.href = 'https://fedauthtst.pg.com/idp/startSSO.ping?PartnerSpId=https%3A%2F%2Fsgraqa.pg.com%3A8212%2Flogin';
        //  }
        //}
        //else {
        //  this._applicationHeaderService.editLoggedInUserDetails(this.loggedInUserDetails);
        //  //this.ProcessRelayStateData();
        //  this._router.navigateByUrl('/dashboard');
        //}
    }

    navigateToFigOrBuyerDashboard() {
        this._router.navigateByUrl("/dashboard");
        //if (this.storageHelper.getItem("selectedRole") == "figBuyer") {
        //    this._router.navigateByUrl("/figdashboard");
        //  //this._router.navigateByUrl("/dashboard");
        //}
        //else if (this.storageHelper.getItem("selectedRole") == "fna" || this.storageHelper.getItem("selectedRole") == "buyer" || this.storageHelper.getItem("selectedRole") == "fddAdmin"
        //    || this.storageHelper.getItem("selectedRole") == "admin_buyer" || this.storageHelper.getItem("selectedRole") == "admin_fna") {
        //    this._router.navigateByUrl("/dashboard");
        //}
    }

    //ProcessRelayStateData() {
    //  if (this.relayState != null && this.relayState != undefined && this.relayState != '') {
    //    let stateInformation = this.relayState.split("/");
    //    if (stateInformation[0] == 'file') {
    //      this.DownloadFile(stateInformation);
    //    }
    //    else if (stateInformation[0] == 'MyApprovals') {
    //      this.storageHelper.setItem("approvalsPageNumber", '1');
    //      this._router.navigateByUrl('/dashboard');
    //    }
    //    else if (stateInformation[0] == 'SIGFATraining') {
    //      this.storageHelper.setItem('OpenTrainingLinks', 'true');
    //      this._router.navigateByUrl('/dashboard');
    //    }
    //    else {
    //      this.GetAssessmentDetailsAndRedirect(stateInformation);
    //    }
    //  }
    //  else {
    //    this.loggedInUserDetails = this.storageHelper.getItem('loggedInUserDetails');
    //    this._router.navigateByUrl('/dashboard');
    //  }
    //}

    //DownloadFile(fileInfo: string[]) {
    //  this.attachmentInfo = {

    //    AssessmentId: parseInt(fileInfo[1]),
    //    AttachmentKey: fileInfo[2],
    //    AttachmentName: fileInfo[3]
    //  };    
    //  this._commonService.downloadAttachmentFromServer(this.attachmentInfo)
    //    .subscribe(resp => {
    //      //this.showLoader = false;
    //      let downloadData = <IDownloadAttachment>resp;
    //      this._commonService.downloadResponse(downloadData.AssessmentData, downloadData.AssessmentName);
    //      this._router.navigateByUrl('/dashboard');
    //    });

    //}

    //GetAssessmentDetailsAndRedirect(stateInfo: string[]) {

    //  let assessmentId = parseInt(stateInfo[1]);

    //  this._commonService.getAssessmentRoleDetails(assessmentId)
    //    .subscribe(resp => {
    //      let assessmentRoleDetails = <any>resp;
    //      let isEditable = false;
    //      if (assessmentRoleDetails.OwnerId == this.loggedInUserDetails.UserId && stateInfo[0].toLowerCase() != 'approval') {
    //        isEditable = true;
    //      }
    //      var assessmentDetails: IRequiredAssessmentDetails = {
    //        AssessmentId: assessmentId,
    //        IsEditable: isEditable
    //      }
    //      this.storageHelper.setItem("requiredAssessmentDetails", assessmentDetails);
    //      this._router.navigateByUrl('/' + stateInfo[0].toLowerCase());
    //    },
    //    error => {
    //      this._router.navigateByUrl('/dashboard');
    //    });
    //}  
}
