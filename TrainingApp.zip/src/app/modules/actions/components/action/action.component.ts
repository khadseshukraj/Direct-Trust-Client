import { Component, OnInit } from '@angular/core';
import { IActionCard } from '../../interfaces/iaction-cards';
import { ApplicationHeaderService } from 'src/app/layout/services/application-header.service';
import { StorageHelper } from 'src/app/core/services/storage-helper.service';
import { SidebarService } from 'src/app/layout/services/sidebar.service';
import { IUserDetails } from '../../../../modules/shared/interfaces/icommon';
@Component({
    selector: 'app-action',
    templateUrl: './action.component.html',
    styleUrls: ['./action.component.scss']
})
export class ActionComponent implements OnInit {

    selectedRole: string = "";
    loggedInUserDetails: IUserDetails = {};
    constructor(private _headerService: ApplicationHeaderService, private _storageHelper: StorageHelper, private _sidebarService: SidebarService) { }

    ngOnInit() {
        this._storageHelper.setItem("currentState", "actions");
        this._sidebarService.setActiveState("actions");

        if (this._storageHelper.getItem("selectedRole") != null && this._storageHelper.getItem("selectedRole") != undefined && this._storageHelper.getItem("selectedRole") != "") {
            this.selectedRole = this._storageHelper.getItem("selectedRole");
        }
        if (this._storageHelper.getItem("loggedInUserDetails") != null) {
            this.loggedInUserDetails = this._storageHelper.getItem("loggedInUserDetails");
        }
        debugger;
        this.adminActionCardList = [
            {
                Title: "Incoming Messages", Description: "Incoming Messages to be Processed",
                IconClass: "icon-reassign", IconBgColor: "#1dd1a1", Route: "/referrer/incomingmessage", AllowedRoles: ["system administrator", "front desk"]
            },
            {
                Title: "DirectTrust Referrer", Description: "Add/Modify/Delete DirectTrust Referrer Details",
                IconClass: "icon-copy", IconBgColor: "#70a1ff", Route: "/referrer",
                AllowedRoles: ["system administrator"]
            },
            {
                Title: "Work in progress Messages", Description: "Work in progress Messages",
                IconClass: "icon-projects", IconBgColor: "#ff6b6b", Route: "/referrer/wipmessage",
                AllowedRoles: [""]
            },
            {
                Title: "Direct Trust POC Not Found Messages", Description: "Direct Trust POC Not Found Messages",
                IconClass: "icon-send-email", IconBgColor: "#35393e", Route: "/referrer/dtpocnotfoundmessage",
                AllowedRoles: [""]
            },
            {
                Title: "Patient Referral Processed Messages", Description: "Direct Trust Processed Messages",
                IconClass: "icon-send-email", IconBgColor: "#35393e", Route: "/referrer/processedmessages",
                AllowedRoles: ["front desk"]
            },
            {
                Title: "Cilnic Mapping", Description: "Cilnic Mapping",
                IconClass: "icon-send-email", IconBgColor: "#35393e", Route: "/referrer/clinicmapping",
                AllowedRoles: ["system administrator"]
            },

             {
                Title: "POC's Sent For Approval", Description: "POC's Sent For Approval",
                IconClass: "icon-send-email", IconBgColor: "#35393e", Route: "/referrer/sentPocs",
                AllowedRoles: ["front desk"]
            },
            {
                Title: "POC's Processed", Description: "POC's Processed",
                IconClass: "icon-send-email", IconBgColor: "#35393e", Route: "/referrer/ProcessedPocs",
                AllowedRoles: ["front desk"]
            },
        ];

        this.actionCardList = this.adminActionCardList;

        if (this.loggedInUserDetails.Roles.trim().toLowerCase() == "front desk") {
            this.actionCardList = this.adminActionCardList.filter(x => x.AllowedRoles.some(y => y.toLowerCase() == "front desk"));
        }
        else {
            this.actionCardList = this.adminActionCardList.filter(x => x.AllowedRoles.some(y => y.toLowerCase() == "system administrator"));;
        }
    }


    adminActionCardList: IActionCard[];
    actionCardList: IActionCard[];
    figActionCardList: IActionCard[];
    receptionistActionCardList: IActionCard[];

}
