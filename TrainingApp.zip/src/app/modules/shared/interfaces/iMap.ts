
export interface iMap {
  id?: string; //Country Code
  value?: number; //Amount
  name?: string; //Sub Region description
  isSelected?: boolean; //is region or contry selected
  subRegionCode?: string; // Sub Region Code
  color?: string
}
