export interface IAngularGrid {
  columnDef?: string,
  header?: string,
  cell?: any
}
