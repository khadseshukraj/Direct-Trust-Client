import { Component, OnInit, ViewChild, Inject, ViewEncapsulation } from '@angular/core';
import { ApplicationHeaderService } from 'src/app/layout/services/application-header.service';
import { StorageHelper } from 'src/app/core/services/storage-helper.service';
import { SidebarService } from 'src/app/layout/services/sidebar.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { ModalStaticClass } from '../../../shared/components/modal/ModalStaticClass';
import { SharedService } from 'src/app/modules/shared/services/shared.service';
import { MatPaginator } from '@angular/material';
import { ReferralService } from 'src/app/modules/emrpage/services/referral.service';
import { IDirectTrustReferrers, IDirectTrustReferrer, IDirectTrustReferrerDelete, IIncomingMessages, IIncomingMessage } from 'src/app/modules/emrpage/Interface/iadmin';
import { NgForm, FormControl, Validators } from '@angular/forms';
import { IUserDetails } from 'src/app/modules/shared/interfaces/icommon';
import { DatePipe } from '@angular/common';
import { Router, CanLoad, UrlSegment, CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot } from '@angular/router';
import { SelectionModel } from '@angular/cdk/collections';

@Component({
  selector: 'app-incomingmessage',
  templateUrl: './incomingmessage.component.html',
  styleUrls: ['./incomingmessage.component.scss']
})
export class IncomingmessageComponent implements OnInit {
    displayedColumns = ['From', 'To', 'Received', 'Subject'];
    DTincomingMessages: IIncomingMessages = { PageSize: 20, MaxPageSize: 30 };
    DTincomingMessage: IIncomingMessage = {};
    noRecordsMessage: string = "";

    angularDataSource: MatTableDataSource<IIncomingMessage> = new MatTableDataSource(this.DTincomingMessages.IncomingMessages);
    pageSizeOptions: number[] = [10, 20, 30];
    loadingData: boolean = false;
    loggedInUserDetails: IUserDetails = {};
    selection = new SelectionModel<IIncomingMessage>(false, []);

    @ViewChild(MatPaginator, null) paginator: MatPaginator;
    @ViewChild(MatSort, null) sort: MatSort;

    constructor(private _headerService: ApplicationHeaderService, private _storageHelper: StorageHelper, private _sidebarService: SidebarService,
        private modalDialog: MatDialog, private _referrerservice: ReferralService, private _navigate: Router,
        public datepipe: DatePipe) {
       
    }

    ngOnInit() {

        this._sidebarService.setActiveState("incomingmessage");
        this._sidebarService.editSidebarShowValue(true);
        if (this._storageHelper.getItem("loggedInUserDetails") != null) {
            this.loggedInUserDetails = this._storageHelper.getItem("loggedInUserDetails");
        }
        this.getIncomingMessageList();
        
    }
    getIncomingMessageList() {
        this.loadingData = true;
        console.log(this.loggedInUserDetails);
        this._referrerservice.getIncomingMessageList(this.loggedInUserDetails.LoginName, this.loggedInUserDetails.Roles).subscribe(
            res => {
                this.DTincomingMessages.IncomingMessages = <IIncomingMessage[]>res;
                this.DTincomingMessages.IncomingMessages.forEach(x => {
                    x.Received = new Date(this.datepipe.transform(x.Received, 'yyyy/MM/dd'));
                    return x;
                });

                this.loadingData = false;
                this.DTincomingMessages.TotalRecords = this.DTincomingMessages.IncomingMessages.length || 0;
                this.DTincomingMessages.TotalPages = Math.ceil(this.DTincomingMessages.TotalRecords / this.DTincomingMessages.PageSize);
                this.DTincomingMessages.CurrentPage = 0;
                this.angularDataSource = new MatTableDataSource(this.DTincomingMessages.IncomingMessages.slice(0, this.DTincomingMessages.PageSize));
                this.selection = new SelectionModel<IIncomingMessage>(false, []);
                if (this.DTincomingMessages.IncomingMessages.length <= 0) {
                    this.noRecordsMessage = "No records found.";
                }
                else {
                    this.noRecordsMessage = "";
                }
            },
            err => { });

    }
    //Paginator
    getPaginationData(pageEvent: any) {
        if (pageEvent.pageIndex != pageEvent.previousPageIndex) {
            //this.figDetail_Param.TNumber = this.loggedInUserDetails.TNumber;
            this.DTincomingMessages.CurrentPage = pageEvent.pageIndex;
            this.DTincomingMessages.PageSize = pageEvent.pageSize;
            this.angularDataSource.data = this.DTincomingMessages.IncomingMessages.slice((this.DTincomingMessages.CurrentPage * this.DTincomingMessages.PageSize), (((this.DTincomingMessages.CurrentPage + 1) * this.DTincomingMessages.PageSize) + 1));
            this.angularDataSource.sort = this.sort;
        }
        else {
            this.angularDataSource.data = this.DTincomingMessages.IncomingMessages.slice(0, pageEvent.pageSize);
            this.angularDataSource.sort = this.sort;
        }
    }
    ngAfterViewInit() {

    }
    getMessageDetail(row: any) {
        if (this.loggedInUserDetails.Roles.toLocaleLowerCase() == 'front desk') {
            this._navigate.navigate(['/referrer/incomingmessage/incomingmessagedetail/' + row.ID + '/edit']);
        }
        
    }
    
}



